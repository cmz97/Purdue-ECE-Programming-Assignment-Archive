void Quick_Sort(long * Array, int Size);
void Merge_sort(long * Array, int Size);
